package pl.edu.pwr.dkocyla.np;

import org.apache.commons.configuration2.PropertiesConfiguration;
import org.apache.commons.configuration2.builder.fluent.Configurations;
import org.apache.commons.configuration2.ex.ConfigurationException;
import tools.jackson.databind.ObjectMapper;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class Main {

    public static void main(String[] args)
            throws ConfigurationException, IOException, NoSuchAlgorithmException {

        // ===== ZADANIE 3: odczyt ustawień z pliku appsettings.properties =====
        // Tworzy obiekt pomocniczy biblioteki Apache Commons Configuration.
        Configurations configs = new Configurations();

        // Wczytuje ustawienie "ordersDirectory" z pliku konfiguracyjnego aplikacji.
        PropertiesConfiguration config =
                configs.properties(
                        new File("src/main/resources/appsettings.properties")
                );

        // Pobiera ścieżkę katalogu z zamówieniami z konfiguracji, zamiast wpisywać ją na stałe w kodzie.
        String ordersDirectory =
                config.getString("ordersDirectory");

        // ===== ZADANIE 4: wyszukanie wszystkich plików .json z katalogu zamówień =====
        File directory = new File(ordersDirectory);

        // Wyszukuje bezpośrednio w tym katalogu wyłącznie pliki z rozszerzeniem .json.
        File[] jsonFiles = directory.listFiles(
                (dir, name) -> name.endsWith(".json")
        );

        // listFiles zwraca null, gdy katalog nie istnieje albo nie można go odczytać.
        if (jsonFiles == null) {
            System.out.println("Nie udało się odczytać katalogu: " + ordersDirectory);
            return;
        }

        // ===== ZADANIE 2: format pliku JSON odpowiada klasom Customer, Product i OrderRequest =====
        // ===== ZADANIE 5: deserializacja JSON-a i nadanie numeru zamówieniu =====
        // ObjectMapper zamienia dane JSON na obiekty klas Java i odwrotnie.
        ObjectMapper mapper = new ObjectMapper();

        // Przetwarza każde znalezione żądanie zamówienia.
        for (File file : jsonFiles) {

            // Deserializacja: zawartość pliku JSON staje się obiektem OrderRequest.
            OrderRequest order =
                    mapper.readValue(file, OrderRequest.class);

            // Numer powstaje z danych zamówienia, więc te same dane zawsze dają ten sam numer.
            String orderNumber =
                    generateOrderNumber(order);

            System.out.println(
                    "Plik: " + file.getName()
                            + " | Numer zamówienia: "
                            + orderNumber
            );
        }
    }

    private static String generateOrderNumber(OrderRequest order)
            throws NoSuchAlgorithmException {

        // ===== ZADANIE 5: deterministyczne generowanie numeru zamówienia =====
        // Ten tekst zawiera wszystkie dane, które mają wpływ na identyfikator zamówienia.
        StringBuilder data = new StringBuilder();

        // Dodaje dane zamawiającego w stałej kolejności.
        data.append(order.getCustomer().getName()).append("|");
        data.append(order.getCustomer().getLastName()).append("|");
        data.append(order.getCustomer().getEmail()).append("|");
        data.append(order.getCustomer().getPhoneNumber()).append("|");

        // Dodaje dane każdego produktu - także ich kolejność wpływa na numer zamówienia.
        for (Product product : order.getProducts()) {
            data.append(product.getCode()).append("|");
            data.append(product.getQuantity()).append("|");
            data.append(product.getUnit()).append("|");
        }

        // SHA-256 tworzy deterministyczny skrót tekstu danych zamówienia.
        MessageDigest digest =
                MessageDigest.getInstance("SHA-256");

        byte[] hash = digest.digest(
                data.toString().getBytes(StandardCharsets.UTF_8)
        );

        // Zamienia bajty skrótu na czytelny zapis szesnastkowy.
        StringBuilder hex = new StringBuilder();

        for (byte b : hash) {
            hex.append(String.format("%02x", b));
        }

        // Prefiks ułatwia rozpoznanie, że jest to numer zamówienia.
        return "ORD-" + hex;
    }
}
